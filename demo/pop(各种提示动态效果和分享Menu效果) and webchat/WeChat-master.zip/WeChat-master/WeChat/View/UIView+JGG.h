//
//  UIView+JGG.h
//  WeChat
//
//  Created by zhengwenming on 16/6/4.
//  Copyright © 2016年 zhengwenming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (JGG)
-(void)distributeSpacingHorizontallyWith:(NSArray*)views;
- (void)distributeSpacingVerticallyWith:(NSArray*)views;
@end
