//
//  DiscoverViewController.h
//  WeChat
//
//  Created by zhengwenming on 16/6/5.
//  Copyright © 2016年 zhengwenming. All rights reserved.
//

#import "BaseViewController.h"
#import "CommentViewController.h"

@interface DiscoverViewController : BaseViewController
@property(nonatomic,strong)CommentViewController *commentVC;
@end
