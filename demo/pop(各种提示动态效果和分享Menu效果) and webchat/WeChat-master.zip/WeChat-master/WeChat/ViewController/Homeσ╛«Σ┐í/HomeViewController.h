//
//  HomeViewController.h
//  WeChat
//
//  Created by zhengwenming on 16/6/5.
//  Copyright © 2016年 zhengwenming. All rights reserved.
//

#import "BaseViewController.h"

@interface HomeViewController : BaseViewController

@end
