//
//  Ads.h
//  SDAutoLayoutDemo
//
//  Created by lixiya on 16/1/14.
//  Copyright © 2016年 lixiya. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Ads : NSObject

@property (nonatomic,copy) NSString *title;
@property (nonatomic,copy) NSString *tag;
@property (nonatomic,copy) NSString *imgsrc;
@property (nonatomic,copy) NSString *subtitle;
@property (nonatomic,copy) NSString *url;

@end
