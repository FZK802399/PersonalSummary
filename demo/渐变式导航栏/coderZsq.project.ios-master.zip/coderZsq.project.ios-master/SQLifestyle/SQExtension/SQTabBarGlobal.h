//
//  SQTabBarGlobal.h
//
//  Created by Doubles_Z on 16-6-15.
//  Copyright (c) 2016年 Doubles_Z. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSInteger _preIndex;
extern NSInteger _selectedIndex;
