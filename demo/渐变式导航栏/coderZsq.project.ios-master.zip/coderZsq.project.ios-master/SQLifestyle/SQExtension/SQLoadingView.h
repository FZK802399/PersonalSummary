//
//  SQLoadingView.h
//
//  Created by Doubles_Z on 16/6/13.
//  Copyright © 2016年 Doubles_Z. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SQLoadingView : UIView

@property (nonatomic,strong) CALayer * loadingLayer;

@end
