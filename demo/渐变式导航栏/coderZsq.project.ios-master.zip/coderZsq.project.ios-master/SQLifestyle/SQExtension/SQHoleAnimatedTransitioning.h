//
//  SQHoleAnimatedTransitioning.h
//
//  Created by Doubles_Z on 16/7/1.
//  Copyright (c) 2016年 Doubles_Z. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface SQHoleAnimatedTransitioning : NSObject<UIViewControllerAnimatedTransitioning>

@property (nonatomic,assign) CGRect frame;

@end
