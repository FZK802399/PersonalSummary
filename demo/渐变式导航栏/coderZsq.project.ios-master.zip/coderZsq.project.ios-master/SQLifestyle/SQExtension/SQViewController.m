//
//  SQViewController.m
//  SQLifestyle
//
//  Created by Doubles_Z on 16-7-1.
//  Copyright (c) 2016年 Doubles_Z. All rights reserved.
//

#import "SQViewController.h"

@interface SQViewController ()

@end

@implementation SQViewController

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    kCurrentViewController = self;
}

@end
