//
//  SQVariableGlobal.m
//  SQLifestyle
//
//  Created by Doubles_Z on 16-7-1.
//  Copyright (c) 2016年 Doubles_Z. All rights reserved.
//

#import "SQVariableGlobal.h"

@implementation SQVariableGlobal

UIViewController * kCurrentViewController = nil;

@end
