//
//  SQVariableGlobal.h
//  SQLifestyle
//
//  Created by Doubles_Z on 16-7-1.
//  Copyright (c) 2016年 Doubles_Z. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SQVariableGlobal : NSObject

extern UIViewController * kCurrentViewController;

@end
