//
//  SQDiscoverViewController.h
//  SQLifestyle
//
//  Created by Doubles_Z on 16-5-22.
//  Copyright (c) 2016年 Doubles_Z. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SQDiscoverViewController : SQViewController

@end
