//
//  SQDiscoverViewController.m
//  SQLifestyle
//
//  Created by Doubles_Z on 16-5-22.
//  Copyright (c) 2016年 Doubles_Z. All rights reserved.
//

#import "SQDiscoverViewController.h"

@interface SQDiscoverViewController ()

@end

@implementation SQDiscoverViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = GLOBAL_BGC;
}

@end
